# 🐄 GanadoApp — PWA

Sistema de gestión ganadera bovina con lectura de caravanas electrónicas.

---

## 📁 Archivos del proyecto

```
ganadoapp-pwa/
├── index.html       ← La app completa
├── manifest.json    ← Configuración PWA
├── sw.js            ← Service Worker (offline)
├── icons/
│   ├── icon-72.png
│   ├── icon-96.png
│   ├── icon-128.png
│   ├── icon-192.png
│   └── icon-512.png
└── README.md
```

---

## 🚀 Paso a paso: subir a GitHub Pages

### 1. Crear repositorio en GitHub

1. Entrá a [github.com](https://github.com) con tu cuenta
2. Click en el botón verde **"New"** (arriba a la izquierda)
3. **Repository name:** `ganadoapp` (todo minúscula, sin espacios)
4. Dejalo en **Public**
5. Click en **"Create repository"**

### 2. Subir los archivos

En la página del repositorio vacío, vas a ver un enlace que dice **"uploading an existing file"**. Hacé click ahí.

Arrastrá o seleccioná **todos los archivos**:
- `index.html`
- `manifest.json`  
- `sw.js`
- La carpeta `icons/` completa (con los 5 PNGs adentro)

En el campo de abajo escribí: `Primera versión PWA`

Click en **"Commit changes"** (botón verde).

### 3. Activar GitHub Pages

1. En tu repositorio, click en **"Settings"** (arriba a la derecha)
2. En el menú izquierdo, click en **"Pages"**
3. En **"Source"** seleccioná **"Deploy from a branch"**
4. En **"Branch"** seleccioná **"main"** y la carpeta **"/ (root)"**
5. Click en **"Save"**

Esperá 2-3 minutos. Aparecerá un mensaje verde con la URL:

```
https://TU-USUARIO.github.io/ganadoapp/
```

¡Esa es tu app en internet!

---

## 📲 Instalar en Android como app

### Método 1: Botón automático (recomendado)
1. Abrí Chrome en tu Android
2. Entrá a `https://TU-USUARIO.github.io/ganadoapp/`
3. En el topbar de la app aparece el botón **"📲 Instalar app"**
4. Tocalo → confirmá → listo

### Método 2: Manual desde Chrome
1. Abrí Chrome y entrá a la URL
2. Tocá los **tres puntos** (⋮) arriba a la derecha
3. Tocá **"Agregar a pantalla de inicio"**
4. Confirmá el nombre → **"Agregar"**

La app aparece en tu pantalla de inicio con el ícono de la vaca 🐄.  
Se abre **sin barra del navegador**, funciona **offline** y se comporta como una app nativa.

---

## ✅ Verificar que funciona offline

1. Abrí la app instalada
2. Activá el **modo avión** en el celular
3. Cerrá y volvé a abrir la app
4. Tiene que funcionar normalmente ✓

---

## 🔄 Actualizar la app

Cuando hagas cambios al código:
1. Entrá a tu repositorio en GitHub
2. Click en `index.html`
3. Click en el lápiz ✏️ (editar)
4. Hacé los cambios o reemplazá el contenido
5. Click en **"Commit changes"**

GitHub Pages actualiza en 1-2 minutos.  
Los usuarios verán la actualización la próxima vez que abran la app con conexión.

---

## 🔧 Datos técnicos

- **Stack:** HTML + CSS + JavaScript puro, sin frameworks
- **Persistencia:** localStorage (datos en el dispositivo)
- **Offline:** Service Worker con estrategia Cache First
- **HTTPS:** GitHub Pages incluye HTTPS automático (requerido para PWA)
- **Compatible:** Chrome Android, Chrome iOS, Edge, Samsung Internet

---

*GanadoApp v2.0 — Etapa 1 Local/PWA*
